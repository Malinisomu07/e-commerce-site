import product1Image from "../assets/explore-img/earbuds.png";
import product2Image from "../assets/explore-img/headphone.png";
import product3Image from "../assets/explore-img/keyboard.png";
import product4Image from "../assets/explore-img/macbook.png";
import product5Image from "../assets/explore-img/remote.png";
import product6Image from "../assets/explore-img/smartwatch.png";

const CartData = {
  cartproducts: [
    {
      "ID": 234545,
      className: "product-item",
      imgSrc: product1Image,
      imgAlt: "Product 1",
      title: "Bluetooth Earbuds : Wireless earbuds with Bluetooth connectivity.",
    },
    {
      "ID": 123456,
      className: "product-item",
      imgSrc: product2Image,
      imgAlt: "Product 2",
      title: "Headphone Wireless : headphones for a tangle-free listening experience.",
      content: " ",
    },
    {
      "ID": 987654,
      className: "product-item",
      imgSrc: product3Image,
      imgAlt: "Product 3",
      title: "Keyboard : A standard keyboard for typing and inputting commands.",
    },
    {
      "ID": 456789,
      className: "product-item",
      imgSrc: product4Image,
      imgAlt: "Product 4",
      title: "MacBook : A portable and powerful laptop computer designed by Apple.",
    },
    {
      "ID": 987123,
      className: "product-item",
      imgSrc: product5Image,
      imgAlt: "Product 5",
      title: "Remote : A device for controlling electronic devices from a distance",
    },
    {
      "ID": 789456,
      className: "product-item",
      imgSrc: product6Image,
      imgAlt: "Product 6",
      title: "Smart Watch : Device with various functionalities like tracking fitness and notifications.",
    },
  ],
};

export default CartData;
